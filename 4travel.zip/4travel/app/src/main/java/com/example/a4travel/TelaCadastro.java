package com.example.a4travel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TelaCadastro extends AppCompatActivity {

    EditText emailLogin;
    EditText senhaLogin;
    EditText senhaLoginConfirmar;
    Button btnCadastrar;
    TextView cadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);
        emailLogin = (EditText)findViewById(R.id.emailLogin);
        senhaLogin = (EditText)findViewById(R.id.senhaLogin);
        btnCadastrar = (Button)findViewById(R.id.btnCadastrar);
        cadastrar = (TextView)findViewById(R.id.cadastrar);
        senhaLoginConfirmar = (EditText) findViewById(R.id.senhaLoginConfirmar);

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MainActivity = new Intent(TelaCadastro.this, com.example.a4travel.MainActivity.class);
                startActivity(MainActivity);
            }
        });

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnCadastrar = new Intent(TelaCadastro.this, MainActivity.class);
                startActivity(btnCadastrar);
            }
        });
    }
}