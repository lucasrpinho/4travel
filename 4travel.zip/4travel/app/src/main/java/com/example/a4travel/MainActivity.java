package com.example.a4travel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText emailLogin;
    EditText senhaLogin;
    EditText nomeLogin;
    Button btnLogin;
    TextView cadastrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailLogin = (EditText) findViewById(R.id.emailLogin);
        senhaLogin = (EditText) findViewById(R.id.senhaLogin);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        cadastrar = (TextView) findViewById(R.id.cadastrar);
        nomeLogin = (EditText) findViewById(R.id.nomeLogin);

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent TelaCadastro = new Intent(MainActivity.this, com.example.a4travel.TelaCadastro.class);
                startActivity(TelaCadastro);
            }
        });
    }
}